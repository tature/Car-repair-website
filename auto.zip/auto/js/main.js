




$(function () {
  $('.burger, .overlay, .header__top a').on('click', function () {
    $('.header__top').toggleClass('header__top--open')
    $('.overlay').toggleClass('overlay--show')
    $('.burger').toggleClass('burger--close')
    if($('.burger').hasClass("burger--close") === true){
      $('.burger span').hide(300)
    }
    else{
      $('.burger span').show(300)
    }
  });

  $(".menu__buttons-item").on('click', function() {
    $(".menu__buttons-item").removeClass('is-active');
    $(this).addClass("is-active");
  })

  $(window).on('scroll', function(){
    setInterval(function(){
      if ($(window).scrollTop() > 0 && $('.header__top').hasClass('header__top--open') === false){
        $('.burger').addClass('burger-follow')
      }
      else{
        $('.burger').removeClass('burger-follow')
      }
    },0)
    if ($(window).scrollTop() > 0){
      $('.burger').addClass('burger-follow')
    }
    else{
      $('.burger').removeClass('burger-follow')
    }
  })
})




